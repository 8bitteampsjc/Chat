module.exports = {
    database: 'mongodb://localhost:27017/mernchatapp',
    secret: 'arifsecret'
};